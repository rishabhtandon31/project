package com.cg.paytm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.paytm.beans.Address;
import com.cg.paytm.beans.BankDetails;
import com.cg.paytm.beans.Customer;
import com.cg.paytm.daoservices.BankDetailsDAO;
import com.cg.paytm.daoservices.CustomerDAO;
import com.cg.paytm.exceptions.BankDetailsNotFoundException;
import com.cg.paytm.exceptions.CustomerDetailsNotFoundException;
import com.cg.paytm.exceptions.LoginPasswordNotMatched;
import com.cg.paytm.exceptions.PaytmServicesDownException;

@Component("paytmServices")
public class PaytmServicesImpl implements PaytmServices{
	
	@Autowired
	CustomerDAO customerDAO;
	@Autowired
	BankDetailsDAO bankDetailsDAO;
	
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, long mobileNo, int pinCode,
			String city, String state, String loginPassword) throws PaytmServicesDownException {
		Customer customer=new Customer(firstName, lastName, emailID, mobileNo, loginPassword, new Address(pinCode, city, state));
		customer=customerDAO.save(customer);
		return customer.getCustomerID();
	}
	
	@Override
	public long acceptBankDetails(int customerID, long accountNo, int pinNumber) throws PaytmServicesDownException, CustomerDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer is not found!!"));
		BankDetails bankDetails=bankDetailsDAO.save(new BankDetails(accountNo, pinNumber, customer));
		return bankDetails.getAccountNo();
	}
	
	@Override
	public Customer getCustomerDetailsViaEmail(String emailID, String loginPassword)
			throws CustomerDetailsNotFoundException, PaytmServicesDownException, LoginPasswordNotMatched {
		/*Customer customer=customerDAO.findById(customerID).get();
		if(customer==null) {
			customer=customerDAO.getCustomerDetailsViaEmailID(emailID);
			if(customer==null) throw new CustomerDetailsNotFoundException("Customer is not found!!");
		}*/
		Customer customer=customerDAO.getCustomerDetailsViaEmailID(emailID);
		if(customer==null) throw new CustomerDetailsNotFoundException("Customer Not Found!!");
		if(customer.getLoginPassword().equals(loginPassword)) {
			System.out.println(customer);
			return customer;
		}
		else throw new LoginPasswordNotMatched("Password donot matched! Try Again!!!");
	}
	
	@Override
	public List<BankDetails> getAllBankDetails(int customerID) throws BankDetailsNotFoundException, PaytmServicesDownException {
		return bankDetailsDAO.getAllBankDetails(customerID);
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, PaytmServicesDownException{
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer is not found!!"));
		return customer;
	}

	@Override
	public String generateUpiId(int customerID, String upiId,int upiPassword)
			throws CustomerDetailsNotFoundException, PaytmServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer is not found!!"));
		customer.setUpiId(upiId);
		customer.setUpiPassword(upiPassword);
		customer=customerDAO.save(customer);
		return customer.getUpiId();
	}
	
		
}
