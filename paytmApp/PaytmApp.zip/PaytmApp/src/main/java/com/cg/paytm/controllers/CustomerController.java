package com.cg.paytm.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.paytm.beans.BankDetails;
import com.cg.paytm.beans.Customer;
import com.cg.paytm.exceptions.CustomerDetailsNotFoundException;
import com.cg.paytm.exceptions.LoginPasswordNotMatched;
import com.cg.paytm.exceptions.PaytmServicesDownException;
import com.cg.paytm.services.PaytmServices;

@Controller
public class CustomerController {
	@Autowired
	private PaytmServices paytmServices;
	
	@RequestMapping("/openAccountController")
	public ModelAndView registerCustomer(@ModelAttribute Customer customer,BindingResult result) throws PaytmServicesDownException {
		if(result.hasErrors()) return new ModelAndView("newUserPage");
		int customerID=paytmServices.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(),
				customer.getMobileNo(), customer.getAddress().getPinCode(),customer.getAddress().getCity(),customer.getAddress().getState(), customer.getLoginPassword());
		return new ModelAndView("accountOpenSuccessfulPage", "customerID", customerID);
	}
	
	@RequestMapping("/loginController")
	public ModelAndView loginCustomer(@RequestParam("username")String emailID, @RequestParam("loginPassword")String loginPassword, HttpServletRequest request) throws PaytmServicesDownException {
		try {
			HttpSession session=request.getSession();
			Customer customer= paytmServices.getCustomerDetailsViaEmail(emailID, loginPassword);
			session.setAttribute("customer", customer);
			return new ModelAndView("welcomePage", "customer",customer);
		} catch (CustomerDetailsNotFoundException | LoginPasswordNotMatched e) {
			return new ModelAndView("indexPage", "errorMessage",e.getMessage());
		}
	}
	
	@RequestMapping("/addBankDetailsController")
	public ModelAndView addBankDetails(@ModelAttribute BankDetails bankDetails,BindingResult result, HttpServletRequest request) throws PaytmServicesDownException {
		try {
			HttpSession session=request.getSession(false);
			Customer customer=(Customer) session.getAttribute("customer");
			long accountNo=paytmServices.acceptBankDetails(customer.getCustomerID(), bankDetails.getAccountNo(), bankDetails.getPinNumber());
			customer=paytmServices.getCustomerDetails(customer.getCustomerID());
			if(customer.getUpiId() == null) {
				return new ModelAndView("generateUpiIdPage","message","Your UPI Id is Not Generated!! Generate Now!!");
			}
			return new ModelAndView("addBankDetailsPage", "message","BankDetails is added successfully!!");
			
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("addBankDetailsPage", "errorMessage",e.getMessage());
		}
	}
	
	@RequestMapping("/addUpiPasswordController")
	public ModelAndView addUpiPassword(@RequestParam("upiPin") int upiPin,HttpServletRequest request) throws PaytmServicesDownException {
		try {
			HttpSession session=request.getSession(false);
			Customer customer=(Customer) session.getAttribute("customer");
			String upiId=String.valueOf(customer.getMobileNo())+"@paytm.com";
			upiId=paytmServices.generateUpiId(customer.getCustomerID(), upiId, upiPin);
			return new ModelAndView("generateUpiIdPage", "message","UPI Id "+upiId+" generated successfully!!");
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("generateUpiIdPage", "errorMessage",e.getMessage());
		}
	}
}
