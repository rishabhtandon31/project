package com.cg.paytm.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.paytm.beans.Customer;

@Controller
public class URIController {
	
	@RequestMapping(value= {"/","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/newUserPage")
	public String getNewUserPage() {
		return "newUserPage";
	}
	
	@RequestMapping("/welcomePage")
	public String getWelcomepage() {
		return "welcomePage";
	}
	
	@ModelAttribute
	public Customer getCustomer() {
		Customer customer=new Customer();
		return customer;
	}
}
