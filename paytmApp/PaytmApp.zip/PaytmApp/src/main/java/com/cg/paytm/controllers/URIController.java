package com.cg.paytm.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.paytm.beans.BankDetails;
import com.cg.paytm.beans.Customer;

@Controller
public class URIController {
	
	@RequestMapping(value= {"/","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/newUserPage")
	public String getNewUserPage() {
		return "newUserPage";
	}
	
	@RequestMapping("/welcomePage")
	public String getWelcomepage() {
		return "welcomePage";
	}
	
	@RequestMapping("/addBankDetailsPage")
	public String addBankDetailsPage() {
		return "addBankDetailsPage";
	}
	
	@RequestMapping("/generateUpiIdPage")
	public String generateUpiIdPage() {
		return "generateUpiIdPage";
	}
	
	@ModelAttribute
	public Customer getCustomer() {
		Customer customer=new Customer();
		return customer;
	}
	
	@ModelAttribute
	public BankDetails getBankDetails() {
		return new BankDetails();
	}
}
