package com.cg.paytm.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.paytm.beans.Customer;
import com.cg.paytm.exceptions.CustomerDetailsNotFoundException;
import com.cg.paytm.exceptions.PaytmServicesDownException;

public interface CustomerDAO extends JpaRepository<Customer,Integer>{
	@Query("SELECT c from Customer c where emailID =:emailID")
	public Customer getCustomerDetailsViaEmailID(@Param("emailID")String emailID) throws CustomerDetailsNotFoundException,PaytmServicesDownException;
}
