package com.cg.paytm.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.paytm.beans.BankDetails;
import com.cg.paytm.exceptions.BankDetailsNotFoundException;
import com.cg.paytm.exceptions.PaytmServicesDownException;

public interface BankDetailsDAO extends JpaRepository<BankDetails,Integer>{
	@Query("SELECT b from BankDetails b where b.customer.customerID =:customerID")
	public List<BankDetails>getAllBankDetails(@Param("customerID") int customerID) throws BankDetailsNotFoundException,PaytmServicesDownException;
}
