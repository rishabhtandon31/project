package com.cg.paytm.services;

import java.util.List;

import com.cg.paytm.beans.BankDetails;
import com.cg.paytm.beans.Customer;
import com.cg.paytm.exceptions.BankDetailsNotFoundException;
import com.cg.paytm.exceptions.CustomerDetailsNotFoundException;
import com.cg.paytm.exceptions.LoginPasswordNotMatched;
import com.cg.paytm.exceptions.PaytmServicesDownException;

public interface PaytmServices {
	int acceptCustomerDetails(String firstName,String lastName,String emailID,long mobileNo,
			int pinCode,String city,String state,String loginPassword) throws PaytmServicesDownException;
	long acceptBankDetails(int customerID,long accountNo,int pinNumber) throws PaytmServicesDownException,CustomerDetailsNotFoundException;
	Customer getCustomerDetailsViaEmail(String emailID,String loginPassword) throws CustomerDetailsNotFoundException,PaytmServicesDownException,LoginPasswordNotMatched;
	Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException,PaytmServicesDownException;
	List<BankDetails>getAllBankDetails(int customerID) throws BankDetailsNotFoundException,PaytmServicesDownException;
}
