package com.cg.paytm.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "bankId_seq", sequenceName = "bankId_seq", initialValue=101, allocationSize = 0)
public class BankDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="bankId_seq")
	private int bankId;
	private long accountNo;
	private int pinNumber;
	private int upiPassword;
	@ManyToOne
	private Customer customer;
	public BankDetails() {
		super();
	}
	public BankDetails(long accountNo, int pinNumber, int upiPassword, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.upiPassword = upiPassword;
		this.customer = customer;
	}
	public int getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getUpiPassword() {
		return upiPassword;
	}
	public void setUpiPassword(int upiPassword) {
		this.upiPassword = upiPassword;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
		result = prime * result + bankId;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + pinNumber;
		result = prime * result + upiPassword;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankDetails other = (BankDetails) obj;
		if (accountNo != other.accountNo)
			return false;
		if (bankId != other.bankId)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (pinNumber != other.pinNumber)
			return false;
		if (upiPassword != other.upiPassword)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BankDetails [bankId=" + bankId + ", accountNo=" + accountNo + ", pinNumber=" + pinNumber
				+ ", upiPassword=" + upiPassword + ", customer=" + customer + "]";
	}
	
	
}
