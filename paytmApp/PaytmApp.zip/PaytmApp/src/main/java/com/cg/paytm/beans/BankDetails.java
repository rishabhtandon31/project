package com.cg.paytm.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "bankDetailsId_seq", sequenceName = "bankDetailsId_seq", initialValue=201, allocationSize = 0)
public class BankDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="bankDetailsId_seq")
	private int bankDetailsId;
	private long accountNo;
	private int pinNumber;
	@ManyToOne
	private Customer customer;
	public BankDetails() {
		super();
	}
	public BankDetails(long accountNo, int pinNumber, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.customer = customer;
	}
	public int getBankDetailsId() {
		return bankDetailsId;
	}
	public void setBankDetailsId(int bankDetailsId) {
		this.bankDetailsId = bankDetailsId;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
		result = prime * result + bankDetailsId;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + pinNumber;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankDetails other = (BankDetails) obj;
		if (accountNo != other.accountNo)
			return false;
		if (bankDetailsId != other.bankDetailsId)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (pinNumber != other.pinNumber)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BankDetails [bankDetailsId=" + bankDetailsId + ", accountNo=" + accountNo + ", pinNumber=" + pinNumber
				+ ", customer=" + customer + "]";
	}
	
	
}
