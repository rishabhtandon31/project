package com.cg.paytm.exceptions;

public class LoginPasswordNotMatched extends Exception{
	private static final long serialVersionUID = 1L;
	public LoginPasswordNotMatched() {
		super();
	}
	public LoginPasswordNotMatched(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public LoginPasswordNotMatched(String message, Throwable cause) {
		super(message, cause);
	}
	public LoginPasswordNotMatched(String message) {
		super(message);
	}
	public LoginPasswordNotMatched(Throwable cause) {
		super(cause);
	}
}
