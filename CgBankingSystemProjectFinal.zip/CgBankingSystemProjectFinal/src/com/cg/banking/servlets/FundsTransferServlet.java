package com.cg.banking.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet(name="FundTransferServlet", urlPatterns="/FundTransferServlet")
public class FundsTransferServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	public FundsTransferServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//try {
			long accountNoTo= Long.parseLong(request.getParameter("accountNoTo"));
			long accountNoFrom= Long.parseLong(request.getParameter("accountNoFrom"));
			float transferAmount= Float.parseFloat(request.getParameter("transferAmount"));
			int pinNumber= Integer.parseInt(request.getParameter("passwordText"));
			BankingServices bankingServices =new BankingServicesImpl();
			RequestDispatcher dispatcher= request.getRequestDispatcher("fundTransfer.jsp");
			//boolean result=bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
			boolean result=true;
			if(result){ 
				String message="The funds transfer has been done successfully.";
				request.setAttribute("result", message);
				dispatcher.forward(request, response);
			}
		 /*}catch (InsufficientAmountException e) {} 
		catch (AccountNotFoundException e) {
			RequestDispatcher dispatcher= request.getRequestDispatcher("fundTransfer.jsp");
			request.setAttribute("errorMessage", e.getMessage());
			dispatcher.forward(request, response);
		} 
		catch (InvalidPinNumberException e) {} 
		catch (BankingServicesDownException e) {} 
		catch (AccountBlockedException e) {}
*/
}
}