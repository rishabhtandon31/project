package com.cg.mobilebilling.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class OpenMobileAccountController {
	@Autowired
	private BillingServices billingServices;
	
	@RequestMapping("/openMobileAccount")
	
	public ModelAndView registerCustomer(@RequestParam("choosePlan") String choosePlan,@ModelAttribute Customer customer, BindingResult result) throws BillingServicesDownException {
		//customer.setPostpaidAccounts(null);
		billingServices.acceptCustomerDetails(customer,choosePlan);
		return new ModelAndView("accountOpeningSuccessfulPage", "customer", customer);
	}
	
}
