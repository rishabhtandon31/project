package com.cg.mobilebilling.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

public class MainClass {
		 
		public static void main(String[] args) throws BillingServicesDownException{
			/*ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
			 BillingServices billingServices = (BillingServices) context.getBean("billingServices");
		System.out.println("Your customer  ID is: " + billingServices.acceptCustomerDetails("Rishabh", "Tandon", "rtandon900@gmail.com", "31/10/1995", "Khanna", "Punjab", 141401));
		System.out.println("Done!!!");
			
		*/
	}
}