package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostpaidAccountStepDefination {

	@Given("^User is on openPostpaidMobileAccountPage Page$")
	public void user_is_on_openPostpaidMobileAccountPage_Page() throws Throwable {
		
	}

	@When("^User chooses his plan and click on submit button$")
	public void user_chooses_his_plan_and_click_on_submit_button() throws Throwable {
		
	}

	@Then("^User is redirected to openPostpaidMobileAccountPage page and message gets displayed$")
	public void user_is_redirected_to_openPostpaidMobileAccountPage_page_and_message_gets_displayed() throws Throwable {
	}

	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
	}

}
